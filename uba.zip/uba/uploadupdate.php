
<?php
include('login.php'); 
if(!isset($_SESSION['login_user'])){
  header("location: index.php");
}else{ 


if(isset($_POST['btnUploadDoc1'])){
	$reg=$_POST['upload1'];
	$aadhar=$_POST['upload2'];
	$roll=$_POST['upload3'];
	$std=$_POST['std'];
	$f=$_POST['doc'];


		$name=$_FILES['qq']['name'];
		$type=$_FILES['qq']['type'];
		$file_size =$_FILES['qq']['size'];

	if($file_size>65535){
			echo "<script>alert('File size must be less than 63 kB');</script>";
	}else{
		try{  
      		$dbh=new PDO("mysql:host=localhost;dbname=uba;charset=UTF8","root","");
		
		$data=file_get_contents($_FILES['qq']['tmp_name']);
		if($f=="आधार कार्ड"){
			if($std=="1"||$std=="2"||$std=="3"||$std=="4"||$std=="5"||$std=="6"||$std=="7"){
				$stmt = prepare($sql);
				$stmt=$this->$dbh->prepare("update std".$std." SET aadhar_name=?,aadhar_type=?,aadhar_data=? where reg=? AND aadhar=? AND rollno=?");
			}else{
				
				$stmt=$dbh->prepare("update exist_student SET aadhar_name=?,aadhar_type=?,aadhar_data=? where reg=? AND aadhar=? AND rollno=?");
			
			}
		}else
		{

		}
	
		$stmt->bindParam(1,$name);
		$stmt->bindParam(2,$type);
		$stmt->bindParam(3,$data,PDO::PARAM_LOB);
		$stmt->bindParam(4,$reg);
		$stmt->bindParam(5,$aadhar);
		$stmt->bindParam(6,$roll);
		$stmt->execute();  
		echo "<script>alert('Document Uploaded Successfully!!');  </script>";
        }catch(Exception $e){  
    		Echo "Connection failed" . $e->getMessage();  
   		 }  
	}
}
?>
<!DOCTYPE html>
<html>
<head>
<title>Upload Documents</title>
  <link rel="stylesheet" type="text/css" href="css1.css">

<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<style type="text/css">
	#head1{
    font-size: 35px;
    font-family: cursive;
  }
footer {
  display: block;
   position: fixed;
  left: 0;
  bottom: 0;
  width: 100%;
  background-color: #A81706;
  color: white;
  text-align: center;
}
</style>
	
</head>
<body>

<div id="mySidenav" class="sidenav">
  <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
   <a href="ccard.php">मुख्य पृष्ठ </a>
<a href="view.php">विद्यार्थ्यांची माहिती बघा</a>
   <a href="pass.php">विद्यार्थी उत्तीर्ण करा </a>
    <a href="about.php">About Us</a>
  <a href="logout.php">बाहेर पडा</a>
</div>
<h1 id="head1"><span style="font-size:40px;cursor:pointer" onclick="openNav()">&#9776;</span>&nbsp;&nbsp;<font style="color: #400C0C;font-style: bold;">जिल्हा परिषद शाळा व्यवस्थापन प्रणाली</font></h1>
<script>
function openNav() {
  document.getElementById("mySidenav").style.width = "250px";
}

function closeNav() {
  document.getElementById("mySidenav").style.width = "0";
}
</script>
<br>
<center>
	<form action="uploadupdate.php" method="POST">
<table cellpadding="15" border="0" width="400px">
			<tr>
				<td colspan="2" align="center"><font style="font-size: 20px;"><b>विद्यार्थ्यांचे तपशील अद्यावत करा (UPDATE)</b></font></td>
			</tr>
			<tr>
			<td>रजि नं.: </td><td><input type="text" style="width: 100%;" name="upload1" placeholder="Enter Register No..." required /></td>

		</tr>
		<tr>
			<td>आधार न.: </td><td><input type="text" style="width: 100%;" name="upload2" placeholder="Enter Aadhar No..." required /></td>
		</tr>
		<tr>
			<td>हजेरी क्र.: </td><td><input type="text" style="width: 100%;" name="upload3" placeholder="Enter Roll No..." required /></td>
		</tr>
		<tr>
	    		<td colspan="2">

		<select name="std" id="current" style="width: 100%;" required>
  			<option value="">-- Select Standard --</option>
			<option value="1">1</option>
			<option value="2">2</option>
			<option value="3">3</option>	
			<option value="4">4</option>
			<option value="5">5</option>
			<option value="6">6</option>
			<option value="7">7</option>	
				<option value="8">उत्तीर्ण विद्यार्थी</option>	
		</select>
		</td>
	    	</tr>
	    	<tr>
	    		<td colspan="2">

		<select name="doc" id="current" style="width: 100%;" required>
  			<option value="">-- Select Document --</option>
			<option value="आधार कार्ड">आधार कार्ड</option>
			<option value="जन्म दाखला">जन्म दाखला</option>
			<option value="रेशन कार्ड">रेशन कार्ड</option>	
			<option value="बँकेचे पास बुक">बँकेचे पास बुक</option>		
		</select>
		</td>
	    	</tr>
		<tr>
	    	<td colspan="2"><input type="file" name="qq" style="width: 100%;"></td>
	    	</tr>
	    	
	    	<tr>
	    		<td colspan="2"><input type="submit" name="btnUploadDoc1" value="UPLOAD"></td>
	    	</tr>
</table>
</form>
</center>
<br>
<br>

<footer><br><center>
        <small> Copyright &copy; 2019 UBA, All Rights Reserved</small></center><br>
</footer>
</body>
</html>
<?php
}
?>